# MLM APPLICATION 

This a Multilavel PIN Genarate Application.

### APP Description ###

* Client - Habibur Rahaman
* 1.0
* [Application Link]()

### Using Tools ###

* HTML5
* CSS3
* PHP
* AJAX
* Codeigniter 3.1.4


### guidelines ###

* 10 Level
* Every Level Open when previous level Completed like, One completed then two open.
* PIN Genarate 
* Level One - 2 PIN
* Level Two - 4 PIN
* Level Three - 8 PIN
* Level Four - 16 PIN
* Level Five - 32 PIN
* Level Six - 64 PIN
* Level Seven - 128 PIN
* Level Eight - 256 PIN
* Level Nine - 512 PIN
* Level Ten - 1024 PIN
