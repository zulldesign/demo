<div id="login-page">
    <div class="container">

        <div id="showtime"></div>

            <div class="signup-success">
                <h2>" CONGRATULATION "</h2>
                <br>
                <h3>Your Account has been successfully save. </h3>
                <a href="<?php echo base_url() ?>log-in">Now You May log-in Here</a>
            </div>

    </div>
</div>
