<section id="main-content">
    <section class="wrapper">
        <div class="row" style="padding: 15px">
            <!--LEVEL ONE-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL ONE</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_one"><button type="submit" class="apply-submit disabled">Level One</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL TWO-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Two</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_two"><button type="submit" class="apply-submit disabled">Level Two</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL THREE-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Three</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_three"><button type="submit" class="apply-submit disabled">Level Three</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL FOUR-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Four</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_four"><button type="submit" class="apply-submit disabled">Level Four</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL FIVE-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Five</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_five"><button type="submit" class="apply-submit disabled">Level Five</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL SIX-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Six</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_six"><button type="submit" class="apply-submit disabled">Level Six</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL SEVEN-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Seven</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_seven"><button type="submit" class="apply-submit disabled">Level Seven</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL EIGHT-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Eight</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_eight"><button type="submit" class="apply-submit disabled">Level Eight</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL NINE-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Nine</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_nine"><button type="submit" class="apply-submit disabled">Level Nine</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--LEVEL TEN-->
            <div class="col-lg-4">
                <div class="apply-level">
                    <div class="panel panel-success">
                        <div class="panel-heading" data-target="#one" data-toggle="collapse" style="cursor: pointer">
                            <h3 class="text-center">LEVEL Ten</h3>
                        </div>
                        <div id="one" class=" panel-collapse collapse in">
                            <div class="panel-body">
                                <a href="<?php echo base_url()?>S_Panel/level_ten"><button type="submit" class="apply-submit disabled">Level Ten</button></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
</section>