<?php
include('php-includes/check-login.php');
include('php-includes/connect.php');
$userid = $_SESSION['userid'];
?>
<?php
	// INCLUDE KONEKSI KE DATABASE
	include_once("php-includes/connect.php");

	if (isset($_POST['Submit'])) {
		$nama = mysqli_real_escape_string($con, $_POST['nama']);
		$produk = mysqli_real_escape_string($con, $_POST['produk']);
		$harga = mysqli_real_escape_string($con, $_POST['harga']);
		$email = mysqli_real_escape_string($con, $_POST['email']);
		$filename = $_FILES['gambar']['name'];

		// CEK DATA TIDAK BOLEH KOSONG
		if (empty($nama) || empty($produk) || empty($harga) || empty($email) ||  empty($filename)) {

			if (empty($nama)) {
				echo "<font color='red'>Kolom Nama tidak boleh kosong.</font><br/>";
			}

			if (empty($produk)) {
				echo "<font color='red'>Kolom Produk tidak boleh kosong.</font><br/>";
			}

			if (empty($harga)) {
				echo "<font color='red'>Kolom Harga tidak boleh kosong.</font><br/>";
			}
			
			if (empty($email)) {
				echo "<font color='red'>Kolom Email tidak boleh kosong.</font><br/>";
			}

			if (empty($filename)) {
				echo "<font color='red'>Kolom Gambar tidak boleh kosong.</font><br/>";
			}

			// KEMBALI KE HALAMAN SEBELUMNYA
			echo "<br/><a href='javascript:self.history.back();'>Kembali</a>";
		} else {
			// JIKA SEMUANYA TIDAK KOSONG
			$filetmpname = $_FILES['gambar']['tmp_name'];

			// FOLDER DIMANA GAMBAR AKAN DI SIMPAN
			$folder = 'image/';
			// GAMBAR DI SIMPAN KE DALAM FOLDER
			move_uploaded_file($filetmpname, $folder . $filename);

			// MEMASUKAN DATA DATA + NAMA GAMBAR KE DALAM DATABASE
			$result = mysqli_query($con, "INSERT INTO product(nama,produk,harga,email,gambar) VALUES('$nama', '$produk', '$harga', '$email', '$filename')");

			// MENAMPILKAN PESAN BERHASIL
			echo "<font color='green'>Data Berhasil ditambahkan.";
			echo "<br/><a href='product.php'>Lihat Hasilnya</a>";
		}
	}
	?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Add Product</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php-includes/menu.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Add Product</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-12">
                    	<div class="table-responsive">
                    	<a href="product.php">Show Data</a>
<br><br>
<form
      method="post"
      name="form1"
      enctype="multipart/form-data"
    >
      <table width="25%" border="0">
        <tr>
          <td>Nama</td>
          <td><input type="text" name="nama" /></td>
        </tr>
        <tr>
          <td>Produk</td>
          <td><input type="text" name="produk" /></td>
        </tr>
        <tr>
          <td>Harga</td>
          <td><input type="text" name="harga" /></td>
        </tr>
        <tr>
          <td>Email</td>
          <td><input type="text" name="email" /></td>
        </tr>
        <tr>
          <td>Gambar</td>
          <td><input type="file" name="gambar" /></td>
        </tr>
        <tr>
          <td></td>
          <td><input type="submit" name="Submit" value="Add" /></td>
        </tr>
      </table>
    </form>
                        </div>
                    </div>
                </div>
                <!--/.row-->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
