<?php
include('php-includes/check-login.php');
include('php-includes/connect.php');
$userid = $_SESSION['userid'];
?>
<?php
// INCLUDE KONEKSI KE DATABASE
include_once("php-includes/connect.php");
	
if (isset($_POST['update'])) {
	    // AMBIL ID DATA
	    $id = mysqli_real_escape_string($con, $_POST['id']);
	
 	    // AMBIL NAMA FILE FOTO SEBELUMNYA
	    $data = mysqli_query($con, "SELECT gambar FROM product WHERE id='$id'");
  	    $dataImage = mysqli_fetch_assoc($data);
	    $oldImage = $dataImage['gambar'];
	
   	    // AMBIL DATA DATA DIDALAM INPUT
	    $nama = mysqli_real_escape_string($con, $_POST['nama']);
		$produk = mysqli_real_escape_string($con, $_POST['produk']);
		$harga = mysqli_real_escape_string($con, $_POST['harga']);
		$email = mysqli_real_escape_string($con, $_POST['email']);
        $filename = $_FILES['newImage']['name'];

		// CEK DATA TIDAK BOLEH KOSONG
		if (empty($nama) || empty($produk) || empty($harga) || empty($email) ||  empty($filename)) {

			if (empty($nama)) {
				echo "<font color='red'>Kolom Nama tidak boleh kosong.</font><br/>";
			}

			if (empty($produk)) {
				echo "<font color='red'>Kolom Produk tidak boleh kosong.</font><br/>";
			}

			if (empty($harga)) {
				echo "<font color='red'>Kolom Harga tidak boleh kosong.</font><br/>";
			}
			
			if (empty($email)) {
				echo "<font color='red'>Kolom Email tidak boleh kosong.</font><br/>";
			}

			if (empty($filename)) {
				echo "<font color='red'>Kolom Gambar tidak boleh kosong.</font><br/>";
			}

			// KEMBALI KE HALAMAN SEBELUMNYA
			echo "<br/><a href='javascript:self.history.back();'>Kembali</a>";
		} else {
		    
		    // JIKA FOTO DI GANTI
		if (!empty($filename)) {
			$filetmpname = $_FILES['newImage']['tmp_name'];
			$folder = "image/";

			// GAMBAR LAMA DI DELETE
			unlink($folder . $oldImage) or die("GAGAL");

			// GAMBAR BARU DI MASUKAN KE FOLDER
			move_uploaded_file($filetmpname, $folder . $filename);

			// NAMA FILE FOTO + DATA YANG DI GANTIBARU DIMASUKAN
			$result = mysqli_query($con, "UPDATE product SET nama='$nama',produk='$produk',harga='$harga',email='$email',gambar='$filename' WHERE id=$id");
		}

		// MEMASUKAN DATA YANG DI UPDATE KECUALI GAMBAR
		$result = mysqli_query($con, "UPDATE product SET nama='$nama',produk='$produk',harga='$harga',email='$email' WHERE id=$id");

		// REDIRECT KE HALAMAN INDEX.PHP
		header("Location: product.php");
	}
}
?>
<?php
// AMBIL ID DARI URL
$id = $_GET['id'];

// AMBIL DATA BERDASARKAN ID
$result = mysqli_query($con, "SELECT * FROM product WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
	$name = $res['nama'];
	$age = $res['produk'];
	$harga = $res['harga'];
	$email = $res['email'];
	$image = $res['gambar'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Add Product</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php-includes/menu.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Add Product</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-12">
                    	<div class="table-responsive">
                    	<a href="product.php">Show Data</a>
<br><br>
<form
      method="post"
      name="form1"
      enctype="multipart/form-data"
    >
      <table width="25%" border="0">
        <tr>
          <td>Nama</td>
          <td><input type="text" name="nama" value="<?php echo $name; ?>"></td>
        </tr>
        <tr>
          <td>Produk</td>
          <td><input type="text" name="produk" value="<?php echo $age; ?>"></td>
        </tr>
        <tr>
          <td>Harga</td>
          <td><input type="text" name="harga" value="<?php echo $harga; ?>"></td>
        </tr>
        <tr>
          <td>Email</td>
          <td><input type="text" name="email" value="<?php echo $email; ?>"></td>
        </tr>
        <tr>
			<td>Gambar</td>
			<td><img width="80" src="image/<?php echo $image ?>"></td>
			<td><input type="file" name="newImage"></td>
		</tr>
		<tr>
			<td><input type="hidden" name="id" value=<?php echo $_GET['id']; ?>></td>
			<td><input type="submit" name="update" value="Update"></td>
		</tr>
      </table>
    </form>
                        </div>
                    </div>
                </div>
                <!--/.row-->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>

</body>

</html>
