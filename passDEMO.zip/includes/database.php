<?php
$db = mysqli_connect('sdb-64.hosting.stackcp.net','demodm-35303337cc21','fgmhy181fk','demodm-35303337cc21') or die('Database is not connected !');
?>