<?php

$email = $_POST["email"];
$code = $_POST["code"];
$new_password = $_POST["new_password"];

$connection = mysqli_connect("sdb-64.hosting.stackcp.net", "demodm-35303337cc21", "fgmhy181fk", "demodm-35303337cc21");

$sql = "SELECT * FROM user WHERE email = '$email'";
$result = mysqli_query($connection, $sql);
if (mysqli_num_rows($result) > 0)
{
	$user = mysqli_fetch_object($result);
	if ($user->code == $code)
	{
		$sql = "UPDATE user SET code='', password='$new_password' WHERE email='$email'";
		mysqli_query($connection, $sql);

		echo "Password has been changed";
	}
	else
	{
		echo "Recovery email has been expired";
	}
}
else
{
	echo "Email does not exists";
}
