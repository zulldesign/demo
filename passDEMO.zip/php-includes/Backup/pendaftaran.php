<?php
include('php-includes/connect.php');
$userid = $_SESSION['userid'];
?>
<?php
	// INCLUDE KONEKSI KE DATABASE
	include_once("php-includes/connect.php");

	if (isset($_POST['pendaftaran'])) {
		$nama = mysqli_real_escape_string($con, $_POST['nama']);
		$umur = mysqli_real_escape_string($con, $_POST['umur']);
		$email = mysqli_real_escape_string($con, $_POST['email']);
		$password = mysqli_real_escape_string($con, $_POST['password']);
		$filename = $_FILES['gambar']['name'];
        $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
        $address = mysqli_real_escape_string($con, $_POST['address']);
        $account = mysqli_real_escape_string($con, $_POST['account']);
        $under_userid = mysqli_real_escape_string($con,$_POST['under_userid']);
	    $side = mysqli_real_escape_string($con,$_POST['side']);

        // CEK DATA TIDAK BOLEH KOSONG
		if (empty($nama) || empty($umur) || empty($email) || empty($password) ||  empty($filename) || empty($mobile) || empty($address) || empty($account) || empty($under_userid) || empty($side)) {
        //User filled all the fields.
            
			if (empty($nama)) {
				echo "<font color='red'>Kolom Nama tidak boleh kosong.</font><br/>";
			}

			if (empty($umur)) {
				echo "<font color='red'>Kolom Umur tidak boleh kosong.</font><br/>";
			}

			if (empty($email)) {
				echo "<font color='red'>Kolom Email tidak boleh kosong.</font><br/>";
			}
			
			if (empty($password)) {
				echo "<font color='red'>Kolom Password tidak boleh kosong.</font><br/>";
			}

			if (empty($filename)) {
				echo "<font color='red'>Kolom Gambar tidak boleh kosong.</font><br/>";
			}
			
			if (empty($mobile)) {
				echo "<font color='red'>Kolom Mobile tidak boleh kosong.</font><br/>";
			}

			if (empty($address)) {
				echo "<font color='red'>Kolom Address tidak boleh kosong.</font><br/>";
			}

			if (empty($account)) {
				echo "<font color='red'>Kolom Account tidak boleh kosong.</font><br/>";
			}
			
			if (empty($under_userid)) {
				echo "<font color='red'>Kolom Under_userid tidak boleh kosong.</font><br/>";
			}

			if (empty($side)) {
				echo "<font color='red'>Kolom Side tidak boleh kosong.</font><br/>";
			}

			// KEMBALI KE HALAMAN SEBELUMNYA
			echo "<br/><a href='javascript:self.history.back();'>Kembali</a>";
		} else {
			// JIKA SEMUANYA TIDAK KOSONG
			$filetmpname = $_FILES['gambar']['tmp_name'];

			// FOLDER DIMANA GAMBAR AKAN DI SIMPAN
			$folder = 'image/';
			// GAMBAR DI SIMPAN KE DALAM FOLDER
			move_uploaded_file($filetmpname, $folder . $filename);

			// MEMASUKAN DATA DATA + NAMA GAMBAR KE DALAM DATABASE
			$result = mysqli_query($con, "INSERT INTO user(nama,umur,email,password,gambar,mobile,address,account,under_userid,side) VALUES('$nama', '$umur', '$email', '$password', '$filename', '$mobile', '$address', '$account', '$under_userid', '$side')");

            // MEMASUKAN DATA TREE KE DALAM DATABASE
			$result = mysqli_query($con,"INSERT INTO tree(`userid`) VALUES('$email')");

            // UPDATEKAN DATA TREE KE DALAM DATABASE
			$result = mysqli_query($con,"UPDATE tree set `$side`='$email' where userid='$under_userid'");

            // MEMASUKAN DATA INCOME KE DALAM DATABASE
			$result = mysqli_query($con,"INSERT into income (`userid`) values('$email')");
		
		    // UPDATEKAN DATA TREE=AFFILIATE KE DALAM DATABASE
		    
			// MENAMPILKAN PESAN BERHASIL
			echo "<font color='green'>Data Berhasil ditambahkan.";
			echo "<br/><a href='product.php'>Lihat Hasilnya</a>";
		}
	}
	?>
	<!--/register user-->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Darul Manzil - Pendaftaran</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <div class="panel-title"><center><img src="https://www.darulmanzil.com/wp-content/uploads/2023/10/coollogo_com-245131501.png"></center></div>
                    </div>
                    <div class="panel-body">
                        <div class="col-lg-4">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <center>Pendaftaran</center>
                        </div>
                        <div class="panel-body">
                        <form method="post" name="form1" enctype="multipart/form-data">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Nama" name="nama" type="text" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Umur" name="umur" type="text" value="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Email" name="email" type="email" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" autofocus>
                                </div>
                                <div class="form-group">
                                 <label>Gambar</label>
                                    <input class="form-control" placeholder="Gambar" name="gambar" type="file" value="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Mobile" name="mobile" type="text" value="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Alamat" name="address" type="text" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Nombor Akaun Bank" name="account" type="text" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Under Userid" name="under_userid" type="text" value="">
                                </div>
                                <div class="form-group">
                                 <label>Side</label>
                                    <input type="radio" name="side" value="left"> Reffered
                                    <input type="radio" name="side" value="right"> Other
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
                                <input type="submit" name="pendaftaran" class="btn btn-lg btn-success btn-block" value="Daftar">
                            </fieldset>
                        </form>
                    </div>
                </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
