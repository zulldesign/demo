<?php

$email = $_GET["email"];
$code = $_GET["code"];

$connection = mysqli_connect("sdb-64.hosting.stackcp.net", "demodm-35303337cc21", "fgmhy181fk", "demodm-35303337cc21");

$sql = "SELECT * FROM user WHERE email = '$email'";
$result = mysqli_query($connection, $sql);
if (mysqli_num_rows($result) > 0)
{
	$user = mysqli_fetch_object($result);
	if ($user->code == $code)
	{
		?>
		<form method="POST" action="new-password.php">
			<input type="hidden" name="email" value="<?php echo $email; ?>">
			<input type="hidden" name="code" value="<?php echo $code; ?>">
			
			<input type="password" name="new_password" placeholder="Enter new password">
			<input type="submit" value="Change password">
		</form>
		<?php
	}
	else
	{
		echo "Recovery email has been expired";
	}
}
else
{
	echo "Email does not exists";
}
