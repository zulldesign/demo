<?php
	$db_host = "sdb-64.hosting.stackcp.net";
	$db_user = "demodm-35303337cc21";
	$db_pass = "fgmhy181fk";
	$db_name = "demodm-35303337cc21";
	
	$con =  mysqli_connect($db_host,$db_user,$db_pass,$db_name);
	if(mysqli_connect_error()){
		echo 'connect to database failed';
	}
?>