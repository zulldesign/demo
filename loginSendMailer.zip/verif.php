<?php
$db = mysqli_connect("sdb-t.hosting.stackcp.net", "mailer-3230389b5e", "surausaw769", "mailer-3230389b5e");

    $code = $_GET['code'];

    if (isset($code)) {
    $qry = $db->query("SELECT * FROM user WHERE verified_code='$code'");
    $result = $qry->fetch_assoc();
    
    $db->query("UPDATE user SET is_verif=1 WHERE id='".$result['id']."'");
    echo '<script>alert("Verifikasi berhasil! Sila check login");window.location.assign("login.php");</script>';
}
?>