<?php
session_start();
if (!$_SESSION['user']) {
    header("Location: login.php");
  }
?>
<h1>Ini adalah halaman user setelah berhasil login dan terverifikasi.</h1>