<form method="post" action="process.php">
    <fieldset>
        <div class="form-group">
            <input class="form-control" placeholder="Nama" name="nama" type="text" autofocus>
        </div>
        <div class="form-group">
            <input class="form-control" placeholder="Email" name="email" type="email" autofocus>
        </div>
        <div class="form-group">
            <input class="form-control" placeholder="Password" name="password" type="password" autofocus>
        </div>
        <!-- Change this to a button or input when using this as a form -->
        <input type="submit" name="register" class="btn btn-lg btn-success btn-block" value="Daftar">
        <div class="form-group">
            <p>Login ke akaun anda. <a href="login.php">Login!</a></p>
        </div>
    </fieldset>
</form>